export default function Icon8({ cid }: { cid?: string }) {
  return (
    <svg className="box-content w-auto h-6 block overflow-hidden pointer-events-none 2xl:hidden focus:outline-clr-5 focus:[outline-style:auto] focus:outline-[5px]" data-component="icon" aria-hidden="true" height="24" viewBox="0 0 24 24" width="24" xmlns="http://www.w3.org/2000/svg" focusable="false" fill="currentColor" data-cid={cid}>
      <path d="m11.485 2.143-8 4.8-2 1.2a1 1 0 001.03 1.714L3 9.567V20a2 2 0 002 2h5v-8h4v8h5a2 2 0 002-2V9.567l.485.29a1 1 0 001.03-1.714l-2-1.2-8-4.8a1 1 0 00-1.03 0Z" />
    </svg>
  );
}
