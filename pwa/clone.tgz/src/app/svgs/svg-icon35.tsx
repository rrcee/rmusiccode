export default function Icon35({ cid }: { cid?: string }) {
  return (
    <svg className="box-content w-0 h-0 block absolute top-28 left-0 overflow-hidden" aria-hidden="true" fill="currentColor" data-cid={cid}>
      <defs>
        <mask id="artwork__b" fill="#fff">
          <path d="M.24.24v70.2h10.43c0 33 26.76 59.77 59.77 59.77 33 0 59.77-26.7 59.77-59.7h9.7V.3H.3z" />
        </mask>
        <mask id="artwork__d" fill="#fff">
          <path d="M17.3.23C-2.2-.13.26 14.73.26 14.73s-.1 25.85 14.83 28.3c3.9.06 5.2-5.33 5.2-5.33l-2.2 13.24-4.6 31.26s17.9 5.3 33.4 1.02c.1-12.1 4-43.73 3.9-49.96 3.2 3.7 9 24.97 11 51.1 5.8 1.27 9.3 0 9.3 0S70.9 43.12 54.9 21c-4.7-6.87-16.7-6.87-16.7-6.87-7-.98-8.9-.8-16 .18-7.1 1-6.6 9.5-6.6 9.5s1 5.5-1.4 10.2c-8.1-5-7.1-20.5-7.1-20.5s.5-5.6 8.1-6.8c2.3-1.3 3.9-4.7 2-6.3z" />
        </mask>
        <mask id="artwork__f" fill="#fff">
          <path d="M15.65 12.32L2.2 10.67C1.06 10.54.26 9.5.4 8.4L1.18 2C1.32.88 2.35.07 3.48.2l13.45 1.66c1.12.13 1.92 1.16 1.8 2.28l-.8 6.4c-.13 1.1-1.16 1.92-2.28 1.78z" />
        </mask>
        <mask id="artwork__h" fill="#fff">
          <path id="artwork__g" d="M2.97.2l12.6 1.55-.3 11.72-15.03-2.1z" />
        </mask>
        <mask id="artwork__j" fill="#fff">
          <path d="M.2.24c10.98 3.92 12.35 11.63 12.35 11.63l-.44.8S3.3 10.34.2.25z" />
        </mask>
        <mask id="artwork__l" fill="#fff">
          <path d="M.17.27S7.42.9 5.7 4.77l-.7.98C1 8.05.16.27.16.27z" />
        </mask>
        <mask id="artwork__n" fill="#fff">
          <path d="M.24.24H6.4S7.14 4.8 3.32 4.8C-.5 4.8.24.24.24.24z" id="artwork__m" />
        </mask>
        <mask id="artwork__p" fill="#fff">
          <circle cx="6.46" cy="6.64" r="6.46" />
        </mask>
        <mask id="artwork__r" fill="#fff">
          <circle cx="6.46" cy="6.64" r="6.46" />
        </mask>
        <mask id="artwork__t" fill="#fff">
          <path d="M28 14.83c0 8.06-6.22 14.6-13.9 14.6-7.7 0-13.9-4-13.9-14.6C.2 6.77 6.4.25 14.1.25 21.77.25 28 6.78 28 14.83z" />
        </mask>
        <mask id="artwork__v" fill="#fff">
          <path d="M28 14.83c0 8.06-6.22 14.6-13.9 14.6-7.7 0-13.9-4-13.9-14.6C.2 6.77 6.4.25 14.1.25 21.77.25 28 6.78 28 14.83z" />
        </mask>
        <mask id="artwork__x" fill="#fff">
          <path d="M.55.4l9.95.24s1.64 9.34-2.4 9.6C-1.47 10.54.54.4.54.4z" />
        </mask>
        <mask id="artwork__z" fill="#fff">
          <circle cx="59.77" cy="59.77" r="59.77" />
        </mask>
        <clipPath id="hashtag_landing_page_empty__a">
          <path className="hashtag_landing_page_empty__cls-1" d="M0 0h200v200H0z" />
        </clipPath>
        <clipPath id="hashtag_landing_page_empty_dark_mode__a">
          <path className="hashtag_landing_page_empty_dark_mode__cls-1" d="M0 0h200v200H0z" />
        </clipPath>
        <clipPath id="hashtag_landing_page_error__a">
          <path className="hashtag_landing_page_error__cls-1" d="M-79.58-79.58h459.2v459.2h-459.2z" />
        </clipPath>
        <clipPath id="hashtag_landing_page_error__c">
          <path className="hashtag_landing_page_error__cls-1" d="M189.2 50.73c-44.7 0-83.94 30.59-90.33 67.34-7.88 45.31 26.77 92.29 78 101.2s101.3-23.34 109.2-68.65-28.76-89.53-80.04-98.45a97.63 97.63 0 00-16.75-1.45" />
        </clipPath>
        <clipPath id="hashtag_landing_page_error__b">
          <path className="hashtag_landing_page_error__cls-1" d="M1.49 219.9L124.8 212l-60.67-41.9z" />
        </clipPath>
        <clipPath id="hashtag_landing_page_error_dark_mode__a">
          <path className="hashtag_landing_page_error_dark_mode__cls-1" d="M-78.75-78.75h457.5v457.5h-457.5z" />
        </clipPath>
        <clipPath id="hashtag_landing_page_error_dark_mode__c">
          <path className="hashtag_landing_page_error_dark_mode__cls-1" d="M99.07 118.2c-7.85 45.15 26.68 92 77.76 100.8s100.9-23.25 108.8-68.39-28.69-89.21-79.78-98.1a98.36 98.36 0 00-16.72-1.44c-44.54 0-83.64 30.48-90 67.09" />
        </clipPath>
        <clipPath id="hashtag_landing_page_error_dark_mode__b">
          <path className="hashtag_landing_page_error_dark_mode__cls-1" d="M2.03 219.7l122.87-7.9L64.45 170z" />
        </clipPath>
        <mask id="offline_no_content__b" fill="#fff">
          <use xlinkHref="#offline_no_content__a" />
        </mask>
        <mask id="offline_no_content__d" fill="#fff">
          <use xlinkHref="#offline_no_content__c" />
        </mask>
        <path id="offline_no_content__a" d="M0 194.555V.675h191.961v193.88z" />
        <path d="M.668 18.586C8.545 12.047 15.125 3.19 25.082.49v20.673H.668v-2.577z" id="offline_no_content__c" />
        <clipPath id="empty_search__clip-path">
          <path d="M3.43 126.34H227a29.17 29.17 0 0 0-5.06-24c-4.42-6.11-10-12.51-9.71-28.73s-.4-59.23-20.9-67.3c-28.87-11.37-53.18 18.05-71.57 19s-32.31-9.34-45.87-4.5-11.63 16.68-18.17 19.83-20.58.73-25.18 13.8S34.06 77.8 25 83.73c-8.82 5.75-27.62 9.32-21.57 42.61z" fill="none" />
        </clipPath>
        <clipPath id="chrome_icon__b">
          <use overflow="visible" xlinkHref="#chrome_icon__a" />
        </clipPath>
        <clipPath id="chrome_icon__f">
          <use overflow="visible" xlinkHref="#chrome_icon__e" />
        </clipPath>
        <clipPath id="chrome_icon__j">
          <use overflow="visible" xlinkHref="#chrome_icon__i" />
        </clipPath>
        <clipPath id="chrome_icon__n">
          <use overflow="visible" xlinkHref="#chrome_icon__m" />
        </clipPath>
        <linearGradient id="chrome_icon__c" x1="29.337" x2="81.837" y1="75.021" y2="44.354" gradientUnits="userSpaceOnUse">
          <stop offset="0" stopColor="#a52714" stopOpacity=".6" />
          <stop offset=".66" stopColor="#a52714" stopOpacity="0" />
        </linearGradient>
        <linearGradient id="chrome_icon__d" x1="110.872" x2="52.538" y1="164.495" y2="130.329" gradientUnits="userSpaceOnUse">
          <stop offset="0" stopColor="#055524" stopOpacity=".4" />
          <stop offset=".33" stopColor="#055524" stopOpacity="0" />
        </linearGradient>
        <linearGradient id="chrome_icon__g" x1="121.858" x2="136.547" y1="49.804" y2="114.13" gradientUnits="userSpaceOnUse">
          <stop offset="0" stopColor="#ea6100" stopOpacity=".3" />
          <stop offset=".66" stopColor="#ea6100" stopOpacity="0" />
        </linearGradient>
        <linearGradient id="chrome_icon__h" x1="121.858" x2="136.547" y1="49.804" y2="114.13" gradientUnits="userSpaceOnUse">
          <stop offset="0" stopColor="#ea6100" stopOpacity=".3" />
          <stop offset=".66" stopColor="#ea6100" stopOpacity="0" />
        </linearGradient>
        <linearGradient id="chrome_icon__k" x1="29.337" x2="81.837" y1="75.021" y2="44.354" gradientUnits="userSpaceOnUse">
          <stop offset="0" stopColor="#a52714" stopOpacity=".6" />
          <stop offset=".66" stopColor="#a52714" stopOpacity="0" />
        </linearGradient>
        <radialGradient id="chrome_icon__l" cx="668.176" cy="55.948" r="84.078" gradientTransform="translate(-576)" gradientUnits="userSpaceOnUse">
          <stop offset="0" stopColor="#3e2723" stopOpacity=".2" />
          <stop offset="1" stopColor="#3e2723" stopOpacity="0" />
        </radialGradient>
        <linearGradient id="chrome_icon__o" x1="110.872" x2="52.538" y1="164.495" y2="130.329" gradientUnits="userSpaceOnUse">
          <stop offset="0" stopColor="#055524" stopOpacity=".4" />
          <stop offset=".33" stopColor="#055524" stopOpacity="0" />
        </linearGradient>
        <radialGradient id="chrome_icon__p" cx="597.875" cy="48.52" r="78.044" gradientTransform="translate(-576)" gradientUnits="userSpaceOnUse">
          <stop offset="0" stopColor="#3e2723" stopOpacity=".2" />
          <stop offset="1" stopColor="#3e2723" stopOpacity="0" />
        </radialGradient>
        <radialGradient id="chrome_icon__q" cx="671.844" cy="96.138" r="87.87" gradientTransform="translate(-576)" gradientUnits="userSpaceOnUse">
          <stop offset="0" stopColor="#263238" stopOpacity=".2" />
          <stop offset="1" stopColor="#263238" stopOpacity="0" />
        </radialGradient>
        <radialGradient id="chrome_icon__r" cx="34.286" cy="32.014" r="176.746" gradientUnits="userSpaceOnUse">
          <stop offset="0" stopColor="#fff" stopOpacity=".1" />
          <stop offset="1" stopColor="#fff" stopOpacity="0" />
        </radialGradient>
        <circle id="chrome_icon__a" cx="96" cy="96" r="88" />
        <path id="chrome_icon__e" d="M8 184h83.77l38.88-38.88V116H61.36L8 24.48z" />
        <path id="chrome_icon__i" d="M96 56l34.65 60-38.88 68H184V56z" />
        <path id="chrome_icon__m" d="M21.97 8v40.34L61.36 116 96 56h88V8z" />
        <circle id="ring__dot" cx="4" cy="4" r="2" />
        <linearGradient id="premium_standalone_cairo__paint0_linear_6125_21625" x1="2" y1="22" x2="22" y2="2" gradientUnits="userSpaceOnUse">
          <stop offset="0.3" stopColor="#E1002D" />
          <stop offset="0.9" stopColor="#E01378" />
        </linearGradient>
      </defs>
    </svg>
  );
}
